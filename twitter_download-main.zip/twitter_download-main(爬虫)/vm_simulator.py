import random
from collections import deque
import time

LOG_FILE = "vm_log.txt"
IO_DELAY_MS = 100

class PageReplacementSimulator:
    def __init__(self, pages, frame_count, algorithm='FIFO'):
        self.pages = pages
        self.frame_count = frame_count
        self.algorithm = algorithm.upper()
        self.frames = deque()
        self.page_faults = 0
        self.hits = 0
        self.page_history = []
        self.logs = []

    def run(self):
        if self.algorithm == 'FIFO':
            self.fifo()
        elif self.algorithm == 'LRU':
            self.lru()
        else:
            raise ValueError("Unsupported algorithm. Use FIFO or LRU.")
        self.write_log_to_file()

    def fifo(self):
        for idx, page in enumerate(self.pages):
            log = f"Step {idx + 1}: Request Page {page} => "
            if page in self.frames:
                self.hits += 1
                log += f"HIT | Frames: {list(self.frames)}"
                self.page_history.append((list(self.frames), page, 'HIT'))
            else:
                self.page_faults += 1
                if len(self.frames) == self.frame_count:
                    evicted = self.frames.popleft()
                    log += f"FAULT (Evict {evicted}) | "
                else:
                    log += "FAULT | "
                self.frames.append(page)
                log += f"Frames: {list(self.frames)}"
                log += f"\n[I/O] Simulated disk read delay {IO_DELAY_MS} ms"
                time.sleep(IO_DELAY_MS / 1000.0)
                self.page_history.append((list(self.frames), page, 'FAULT'))
            self.logs.append(log)

    def lru(self):
        frames = []
        recent = []
        for idx, page in enumerate(self.pages):
            log = f"Step {idx + 1}: Request Page {page} => "
            if page in frames:
                self.hits += 1
                recent.remove(page)
                recent.append(page)
                log += f"HIT | Frames: {frames}"
                self.page_history.append((list(frames), page, 'HIT'))
            else:
                self.page_faults += 1
                if len(frames) == self.frame_count:
                    lru_page = recent.pop(0)
                    frames.remove(lru_page)
                    log += f"FAULT (Evict {lru_page}) | "
                else:
                    log += "FAULT | "
                frames.append(page)
                recent.append(page)
                log += f"Frames: {frames}"
                log += f"\n[I/O] Simulated disk read delay {IO_DELAY_MS} ms"
                time.sleep(IO_DELAY_MS / 1000.0)
                self.page_history.append((list(frames), page, 'FAULT'))
            self.logs.append(log)

    def print_summary(self):
        print("\n==== 结果 ====")
        for i, (frame, page, result) in enumerate(self.page_history):
            print(f"Step {i + 1}: Request Page {page} => {result} | Frames: {frame}")
        print(f"\nTotal Page Requests: {len(self.pages)}")
        print(f"Page Faults: {self.page_faults}")
        print(f"Hits: {self.hits}")
        print(f"Hit Rate: {self.hits / len(self.pages):.2%}")

    def write_log_to_file(self):
        with open(LOG_FILE, 'w', encoding='utf-8') as f:
            for line in self.logs:
                f.write(line + '\n')
            f.write("\n==== 模拟总结 ====\n")
            f.write(f"Total Page Requests: {len(self.pages)}\n")
            f.write(f"Page Faults: {self.page_faults}\n")
            f.write(f"Hits: {self.hits}\n")
            f.write(f"Hit Rate: {self.hits / len(self.pages):.2%}\n")

if __name__ == '__main__':
    simulated_pages = [random.randint(1, 10) for _ in range(20)]
    print("模拟页面访问序列:", simulated_pages)
    simulator = PageReplacementSimulator(pages=simulated_pages, frame_count=4, algorithm='LRU')
    simulator.run()
    simulator.print_summary()
